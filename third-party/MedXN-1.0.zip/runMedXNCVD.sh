java -Xms512M -Xmx2048M -cp resources:desc:descsrc:medtaggerdescsrc:MedXN-1.0.jar:lib/* org.apache.uima.tools.cvd.CVD

